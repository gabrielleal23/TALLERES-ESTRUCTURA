/**
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Universidad Ean (Bogotá - Colombia)
 * Programa de Ingeniería de Sistemas
 * <p>
 * Estructura de Datos - Taller 06
 * Ejercicio: El Estudiante
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 */
package taller06

class Estudiante(
    val codigo: Int = 1001001001,       // Código del estudiante.
    val nombre: String = "Juliana",     // Nombre del estudiante.
    val apellido: String = "Ramírez"    // Apellido del estudiante.
) {
    // -----------------------------------------------------------------
    // Atributos Adicionales
    // -----------------------------------------------------------------
    var cursos: List<Curso> = emptyList()

    // -----------------------------------------------------------------
    // Métodos Contadores
    // -----------------------------------------------------------------

    /**
     * Determine cuántos cursos tienen un número de créditos par
     */
    fun cursosCodigoPar(): Int {
        TODO("Completar")
    }

    /**
     * Determinar y retornar el número de cursos de pregrado que están
     * calificados y cuya carrera sea Sistemas o Ciencia
     */
    fun ejercicio02(): Int {
        TODO("Completar")
    }

    /**
     * Determinar y retornar la cantidad de cursos del estudiante que
     * pertenecen a la carrera que se recibe como parámetro y tienen
     * un número de créditos entre 2 y 4.
     */
    fun ejercicio03(carrera: String): Int {
        TODO("Completar")
    }

    /**
     * Determinar y retornar cuántos cursos que están calificados
     * fueron aprobados por el estudiante
     */
    fun ejercicio04(): Int {
        TODO("Completar")
    }

    /**
     * Determine y retorne cuantos cursos de pregrado que pertenecen
     * a la carrera que se pasa como parámetro, están calificados
     * y tienen una nota por encima de 20, pero por debajo de 40.
     */
    fun ejercicio05(carrera: String): Int {
        TODO("Completar")
    }

    /**
     * Halle la suma de los créditos de todos los cursos que tiene
     * el estudiante
     */
    fun ejercicio06(): Int {
        TODO("Completar")
    }

    /**
     * Halle la suma de los créditos de aquellos cursos
     * que están calificados y que pertenecen a la carrera
     * que se pasa como parámetro y que fueron aprobados
     */
    fun ejercicio07(carrera: String): Int {
        TODO("Completar")
    }

    /**
     * Obtener el promedio normal de las notas de
     * aquellos cursos que han sido calificados
     */
    fun ejercicio08(): Double {
        TODO("Completar")
    }

    /**
     * Calcula el promedio ponderado del estudiante de los cursos que tienen
     * nota asignada. Para hallar el promedio ponderado debe sumarse la
     * multiplicacion de la nota por los creditos y dividirlo por la suma
     * de los créditos. Ojo: SOLO LOS QUE TIENEN NOTA
     */
    fun ejercicio09(): Double {
        TODO("Completar")
    }

    /**
     * Determine y retorne el porcentaje de cursos aprobados
     * del estudiante. Debe ser un número entre 0 y 100
     */
    fun ejercicio10(): Double {
        TODO("Completar")
    }

    /**
     * Obtener y retornar el curso que tiene el código que
     * se pasa como parámetro. Si no existe el código en la
     * lista, deberá retornarse null
     */
    fun ejercicio11(codigo: String): Curso? {
        TODO("Completar")
    }

    /**
     * Escriba un método que retorne el código del
     * primer curso que pertenezca a la carrera que
     * se recibe como parámetro y que tiene el número
     * de créditos que se recibe también como parámetro.
     * Si no existe ese curso, deberá retornarse la
     * cadena vacía ("")
     */
    fun ejercicio12(carrera: String, creditos: Int): String {
        TODO("Completar")
    }
}