/**
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Universidad EAN (Bogotá - Colombia)
 * Departamento de Tecnología - Facultad de Ingeniería
 * Licenciado bajo el esquema Academic Free License version 2.1
 * <p>
 * Ejercicio: Geometría
 * Autor: Universidad EAN - 07 de febrero de 2023
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 */
package taller05


/**
 * Ejercicio 5
 */
fun ejercicio05(r: Double): Double {
    TODO("Completar")
}

/**
 * Ejercicio 6
 */
fun ejercicio06(u: Double): Double {
    TODO("Completar")
}

/**
 * Ejercicio 07
 */
fun ejercicio07(x: Double): Double {
    TODO("Completar")
}

/**
 * Ejercicio 08 - Hipotenusa
 */
fun ejercicio08(tri: Triangulo): Double {
    TODO("Completar")
}

/**
 * Ejercicio 09
 */
fun ejercicio09(a: Double, b: Double): Double {
    TODO("Completar")
}

/**
 * Ejercicio 10
 */
fun ejercicio10(r: Double): Double {
    TODO("Completar")
}

/**
 * Ejercicio 11
 */
fun ejercicio11(r: Double, a: Double): Double {
    TODO("Completar")
}

/**
 * Ejercicio 12
 */
fun ejercicio12(x: Double, y: Double, z: Double): Double {
    TODO("Completar")
}

/**
 * Ejercicio 13
 */
fun ejercicio13(a: Double, b: Double, c: Double, d: Double, e: Double): Double {
    TODO("Completar")
}
