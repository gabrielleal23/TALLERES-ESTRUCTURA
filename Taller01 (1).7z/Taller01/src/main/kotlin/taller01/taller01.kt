/**
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Universidad Ean (Bogotá - Colombia)
 *
 * Unidad de Estudios: Estructura de Datos
 * Taller: 01
 * Fecha: 1 de febrero de 2023
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 */
package taller01

import kotlin.math.*

/* Ejercicio 01 */
fun ejercicio01(primerCorte: Double, segundoCorte: Double, pruebasObjetivas: Double): Double {
    TODO("Realizar el ejercicio 01")
}

/* Ejercicio 02 */
fun ejercicio02(metros: Double): Double {
    TODO("Realizar el ejercicio 02")
}

/* Ejercicio 03 */
fun ejercicio03(x: Double, y: Double): Double {
    TODO("Realizar el ejercicio 03")
}

/* Ejercicio 04 */
fun ejercicio04(base: Double, altura: Double): Pair<Double, Double> {
    TODO("Finalizar el ejercicio 04")
}

/* Ejercicio 05 */
fun ejercicio05(gordos: Int, flacos: Int, numSillasBus: Int): Int {
    TODO("Terminar el ejercicio 05")
}

/* Ejercicio 06 */
fun ejercicio06(x: Double, alfa: Double): Double {
    TODO("Terminar el ejercicio 06")
}

/* Ejercicio 07 */
fun ejercicio07(sueldo: Double): Triple<Double, Double, Double> {
    TODO("Terminar el ejercicio 07")
}

/* Ejercicio 08 */
fun ejercicio08(a: Double, b: Double): Triple<Double, Double, Double> {
    TODO("Completar el ejercicio 08")
}

/* Ejercicio 09 */
fun ejercicio09(r: Double): Double {
    TODO("Completar el ejercicio 09")
}

/* Ejercicio 10 */
fun ejercicio10(r: Double, R: Double): Double {
    TODO("Completar el ejercicio 10")
}

/* Ejercicio 11 */
fun ejercicio11(n: Int, m: Int, k: Int): Pair<Int, Int> {
    TODO("Completar")
}

/* Ejercicio 12 */
fun ejercicio12(nombreHermano1: String, edadHermano1: Int,
                nombreHermano2: String, edadHermano2: Int,
                nombreHermano3: String, edadHermano3: Int): String {
    TODO("Completar el ejercicio 12")
}

/* Ejercicio 13 */
fun ejercicio13(salario: Double): Pair<Double, Double> {
    TODO("Completar el ejercicio 13")
}

/* Ejercicio 14 */
fun ejercicio14(año: Int): Boolean {
    TODO("Completar el ejercicio 14")
}