package taller02

/**
 * Un número complejo consta de una parte real y una parte imaginaria
 */
class NumeroComplejo(var parteReal: Double, var parteImaginaria: Double) {
    // Halla el valor absoluto del número complejo
    fun valorAbsoluto(): Double {
        TODO("Completar")
    }

    // Halla la fase o argumento del número complejo
    fun argumento(): Double {
        TODO("Completar")
    }

    // Halla el inverso o recíproco de un número complejo
    fun inverso(): NumeroComplejo {
        TODO("Completar")
    }

    // Multiplica la parte real y la parte imaginaria por un escalar
    fun productoPorEscalar(escalar: Double) {
        TODO("Completar")
    }

    // Obtiene una versión String del número complejo
    override fun toString(): String {
        return String.format("%.2f + (%.2f)i", parteReal, parteImaginaria)
    }
}

// Función externa que halla la suma de dos números complejos
fun sumarNumComplejos(num1: NumeroComplejo, num2: NumeroComplejo): NumeroComplejo {
    TODO("Completar")
}

// -----------------------------------------------------------------------------------

// Clase Producto
class Producto(val nombre: String,
               val tipo: String,
               var valorUnitario: Double,
               var cantidadBodega: Int,
               val cantidadMinima: Int) {
    // Retornar el IVA correspondiente al producto. Ojo: este IVA depende del tipo de producto.
    fun darIVA(): Double {
        TODO("Completar")
    }

    //  Calcula el valor final del producto, incluyendo el IVA.
    fun calcularPrecioFinal(): Double {
        TODO("Completar")
    }

    // Vende la cantidad de unidades dada por parámetro.
    fun vender(cantidad: Int) {
        TODO("Completar")
    }

    // Aumenta la cantidad de unidades en bodega del producto en la cantidad que se recibe como dato de entrada.
    fun abastecer(cantidad: Int) {
        TODO("Completar")
    }

    // retorna True sin la cantidad en Bodega es menor que la cantidad mínima, y False en caso contrario.
    fun puedeAbastecer(): Boolean {
        TODO("Completar")
    }

    // Obtener una representación visual de un producto.
    override fun toString(): String {
        return "Producto(nombre='$nombre', tipo='$tipo', valorUnitario=$valorUnitario, cantidadBodega=$cantidadBodega, cantidadMinima=$cantidadMinima)"
    }
}